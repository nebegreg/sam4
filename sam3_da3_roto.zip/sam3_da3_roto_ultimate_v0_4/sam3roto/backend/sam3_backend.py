from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Iterator, List, Optional, Sequence, Tuple, Any
import numpy as np
import torch
from PIL import Image

@dataclass
class FrameMasks:
    frame_idx: int
    masks_by_id: Dict[int, np.ndarray]  # obj_id -> mask_u8 (0/255)

def _mask_to_u8(mask) -> np.ndarray:
    # mask may be torch Tensor in [0,1] or bool
    if hasattr(mask, "detach"):
        mask = mask.detach().float().cpu().numpy()
    mask = np.asarray(mask)
    # ensure HxW
    if mask.ndim == 4:
        mask = mask[0,0]
    if mask.max() <= 1.0:
        mask = (mask > 0.5).astype(np.uint8) * 255
    else:
        mask = (mask > 0).astype(np.uint8) * 255
    return mask.astype(np.uint8)

class SAM3Backend:
    """Backend SAM3 basé sur Hugging Face Transformers.

    - PCS image: Sam3Model + Sam3Processor citeturn3view0
    - PCS vidéo: Sam3VideoModel + Sam3VideoProcessor citeturn3view1
    - PVS image: Sam3TrackerModel + Sam3TrackerProcessor citeturn4view0
    - PVS vidéo: Sam3TrackerVideoModel + Sam3TrackerVideoProcessor citeturn3view2
    """
    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.dtype = torch.bfloat16 if (self.device.type == "cuda" and torch.cuda.is_bf16_supported()) else torch.float16 if self.device.type == "cuda" else torch.float32

        self.model_id = "facebook/sam3"
        self._pcs_model = None
        self._pcs_processor = None
        self._pvs_model = None
        self._pvs_processor = None
        self._pcs_video_model = None
        self._pcs_video_processor = None
        self._pvs_video_model = None
        self._pvs_video_processor = None

    def load(self, model_id_or_path: str = "facebook/sam3"):
        from transformers import (
            Sam3Model, Sam3Processor,
            Sam3TrackerModel, Sam3TrackerProcessor,
            Sam3VideoModel, Sam3VideoProcessor,
            Sam3TrackerVideoModel, Sam3TrackerVideoProcessor,
        )
        self.model_id = model_id_or_path

        # PCS image
        self._pcs_model = Sam3Model.from_pretrained(model_id_or_path).to(self.device, dtype=self.dtype)
        self._pcs_processor = Sam3Processor.from_pretrained(model_id_or_path)

        # PVS image
        self._pvs_model = Sam3TrackerModel.from_pretrained(model_id_or_path).to(self.device, dtype=self.dtype)
        self._pvs_processor = Sam3TrackerProcessor.from_pretrained(model_id_or_path)

        # PCS video
        self._pcs_video_model = Sam3VideoModel.from_pretrained(model_id_or_path).to(self.device, dtype=self.dtype)
        self._pcs_video_processor = Sam3VideoProcessor.from_pretrained(model_id_or_path)

        # PVS video
        self._pvs_video_model = Sam3TrackerVideoModel.from_pretrained(model_id_or_path).to(self.device, dtype=self.dtype)
        self._pvs_video_processor = Sam3TrackerVideoProcessor.from_pretrained(model_id_or_path)

    def is_ready(self) -> bool:
        return self._pcs_model is not None

    @torch.no_grad()
    def segment_concept_image(self, image: Image.Image, text: str, threshold: float = 0.5, mask_threshold: float = 0.5) -> Dict[int, np.ndarray]:
        if self._pcs_model is None:
            raise RuntimeError("SAM3 backend not loaded")
        inputs = self._pcs_processor(images=image, text=text, return_tensors="pt").to(self.device)
        outputs = self._pcs_model(**inputs)

        # returns dict with masks/boxes/scores + object_ids
        results = self._pcs_processor.post_process_instance_segmentation(
            outputs,
            threshold=threshold,
            mask_threshold=mask_threshold,
            target_sizes=inputs.get("original_sizes").tolist(),
        )[0]

        masks = results["masks"]  # list[H,W] or tensor
        obj_ids = results.get("object_ids", None)
        out: Dict[int, np.ndarray] = {}

        if obj_ids is None:
            # fallback: assign incremental
            for i, m in enumerate(masks):
                out[i+1] = _mask_to_u8(m)
        else:
            if hasattr(obj_ids, "tolist"):
                obj_ids = obj_ids.tolist()
            for oid, m in zip(obj_ids, masks):
                out[int(oid)] = _mask_to_u8(m)
        return out

    @torch.no_grad()
    def segment_interactive_image(self, image: Image.Image, points: List[Tuple[int,int,int]], boxes: List[Tuple[int,int,int,int,int]], multimask: bool = False) -> np.ndarray:
        if self._pvs_model is None:
            raise RuntimeError("SAM3 backend not loaded")
        # Build inputs according HF doc shapes citeturn4view0
        input_points = None
        input_labels = None
        if points:
            pts = [[ [ [int(x), int(y)] for (x,y,_) in points ] ]]
            lbs = [[ [ int(l) for (_,_,l) in points ] ]]
            # However this yields shape [1,1,P,2] and [1,1,P]
            input_points = pts
            input_labels = lbs

        input_boxes = None
        if boxes:
            # Sam3Tracker expects input_boxes as [[[x1,y1,x2,y2]]] for single object citeturn4view0
            # If multiple boxes, we just pass the first positive box here.
            # For refinement with multiple boxes, you can extend to list of boxes.
            x1,y1,x2,y2,label = boxes[-1]
            input_boxes = [[[int(x1), int(y1), int(x2), int(y2)]]]

        inputs = self._pvs_processor(images=image, input_points=input_points, input_labels=input_labels, input_boxes=input_boxes, return_tensors="pt").to(self.device)
        outputs = self._pvs_model(**inputs, multimask_output=bool(multimask))
        masks = self._pvs_processor.post_process_masks(outputs.pred_masks.cpu(), inputs["original_sizes"])[0]  # [obj,mask,H,W] or [1,3,H,W]
        # choose best: if multimask gives multiple proposals, take first
        m = masks[0,0] if masks.ndim == 4 else masks[0]
        return _mask_to_u8(m)

    @torch.no_grad()
    def track_concept_video(self, frames: Sequence[Image.Image], texts: List[str]) -> Iterator[FrameMasks]:
        if self._pcs_video_model is None:
            raise RuntimeError("SAM3 backend not loaded")
        proc = self._pcs_video_processor
        model = self._pcs_video_model
        session = proc.init_video_session(
            video=list(frames),
            inference_device=self.device,
            processing_device="cpu",
            video_storage_device="cpu",
            dtype=self.dtype,
        )
        proc.add_text_prompt(session, texts)
        for out in model.propagate_in_video_iterator(inference_session=session):
            processed = proc.postprocess_outputs(session, out)
            # processed likely includes: object_ids, masks (tensor)
            obj_ids = processed.get("object_ids", None)
            masks = processed.get("masks", None)
            if masks is None:
                continue
            # masks: [num_obj, H, W] float/bool or [num_obj,1,H,W]?
            if hasattr(masks, "detach"):
                masks_np = masks.detach().float().cpu().numpy()
            else:
                masks_np = np.asarray(masks)
            if masks_np.ndim == 4:
                masks_np = masks_np[:,0]
            if obj_ids is None:
                ids = list(range(1, masks_np.shape[0]+1))
            else:
                ids = obj_ids.tolist() if hasattr(obj_ids, "tolist") else list(obj_ids)
            d = {int(i): _mask_to_u8(m) for i,m in zip(ids, masks_np)}
            yield FrameMasks(frame_idx=int(out.frame_idx), masks_by_id=d)

    @torch.no_grad()
    def track_interactive_video(self, frames: Sequence[Image.Image], prompts: Dict[int, Dict[int, List[Tuple[int,int,int]]]]) -> Iterator[FrameMasks]:
        if self._pvs_video_model is None:
            raise RuntimeError("SAM3 backend not loaded")
        proc = self._pvs_video_processor
        model = self._pvs_video_model
        session = proc.init_video_session(video=list(frames), inference_device=self.device, dtype=self.dtype)

        # Add initial prompts (keyframes)
        for frame_idx in sorted(prompts.keys()):
            for obj_id, pts in prompts[frame_idx].items():
                input_points = [[[[int(x), int(y)] for (x,y,_) in pts]]]
                input_labels = [[[int(l) for (_,_,l) in pts]]]
                proc.add_inputs_to_inference_session(
                    inference_session=session,
                    frame_idx=int(frame_idx),
                    obj_ids=int(obj_id),
                    input_points=input_points,
                    input_labels=input_labels,
                )
                # optional: run model on annotation frame to lock it
                _ = model(inference_session=session, frame_idx=int(frame_idx))

        # propagate
        for out in model.propagate_in_video_iterator(session):
            # out.pred_masks: tensor [1,1,H,W] per object? Actually returns per step. We'll post-process masks.
            masks = proc.post_process_masks([out.pred_masks], original_sizes=[[session.video_height, session.video_width]], binarize=False)[0]
            # masks shape torch.Size([1,1,H,W]) or [num_obj,1,H,W]? We'll flatten.
            masks_np = masks.detach().float().cpu().numpy()
            if masks_np.ndim == 4:  # [A,B,H,W]
                # treat A as num_obj
                out_masks = {i+1: _mask_to_u8(masks_np[i,0]) for i in range(masks_np.shape[0])}
            elif masks_np.ndim == 3:
                out_masks = {1: _mask_to_u8(masks_np[0])}
            else:
                continue
            yield FrameMasks(frame_idx=int(out.frame_idx), masks_by_id=out_masks)
