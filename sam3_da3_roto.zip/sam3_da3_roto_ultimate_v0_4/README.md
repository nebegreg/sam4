# SAM3 + Depth Anything 3 — Roto Ultimate PRO v0.4 (PySide6)

Application standalone pour :
- **Roto / Track** avec **SAM3** (concept prompts PCS + prompts visuels PVS)
- **Edge refinement** (holes/dots/grow-shrink/border-fix/feather/trimap + smoothing temporel)
- **RGB cleanup** (despill + edge-extend/pixel spread + premultiply)
- **Depth / Camera** via **Depth Anything 3** (depth maps, normals, poses caméra, point cloud PLY)
- Export **PNG Alpha**, **PNG RGBA straight**, exports de depth, normals, poses `.npz`, et script Blender pour **FBX/Alembic**.

> Pensé pour un pipeline Autodesk Flame (Rocky Linux) : exports propres, caches locaux, rien de destructif.

---

## 1) Installation (Rocky Linux 9.5, sans sudo)

### a) Créer un venv (recommandé)
```bash
cd ~/tools
mkdir -p sam3roto
cd sam3roto

python3 -m venv .venv
source .venv/bin/activate
python -m pip install -U pip wheel setuptools
```

### b) Installer dépendances Python
```bash
pip install -r requirements.txt
```

### c) Installer Depth Anything 3 (DA3) depuis GitHub
```bash
git clone https://github.com/ByteDance-Seed/Depth-Anything-3.git
cd Depth-Anything-3
pip install -r requirements.txt
pip install -e .
cd ..
```

Le dépôt DA3 fournit une API Python officielle `from depth_anything_3.api import DepthAnything3` et un modèle HF `depth-anything/DA3NESTED-GIANT-LARGE` etc. citeturn1view0

### d) Lancer l’app
```bash
python run.py
```

---

## 2) Utilisation SAM3 (Roto)

### Concepts (PCS)
- Onglet **Seg/Track → Mode: "Concept (PCS)"**
- Entrez un texte (`"person"`, `"red dress"`, `"hard hat"`) puis **Segment frame** :
  - crée/alimente des objets et masque chaque instance.

SAM3 PCS est exposé dans Transformers via `Sam3Model` / `Sam3Processor` citeturn3view0

### Prompts visuels (PVS)
- Mode **Interactive (PVS)** : clics +/- et/ou box sur une frame, puis **Segment frame**.
- Tracking : mode **Tracking vidéo PVS (keyframes)**, zappez sur une frame, posez quelques points,
  puis **Tracker** (propagation dans la vidéo).

Le PVS image utilise `Sam3TrackerModel` / `Sam3TrackerProcessor` avec `input_points`, `input_labels`, `input_boxes` citeturn4view0  
Le PVS vidéo utilise `Sam3TrackerVideoModel` / `Sam3TrackerVideoProcessor` citeturn3view2

---

## 3) Matte / Edges / Hair-ish

L’onglet **Matte** agit sur l’alpha :
- Fill holes / Remove dots (nettoyage CC)
- Grow/Shrink (érosion/dilatation)
- Border fix (fermeture)
- Feather / Trimap band (bords doux)
- Temporal smooth (stabilité)

> Pour les cheveux, le meilleur combo simple est :
> - Trimap band 10–25 px
> - Feather 2–6 px
> - Temporal 40–70%
> puis un despill + edge-extend en RGB.

---

## 4) Depth / Camera (Depth Anything 3)

Onglet **Depth / Camera (DA3)** :
- Charger DA3 (ex: `depth-anything/DA3-BASE` ou `depth-anything/DA3NESTED-GIANT-LARGE`)
- Lancer **Depth + Camera (toute la séquence)**
- Preview depth / normals
- Export :
  - depth PNG16 (seq)
  - normals PNG (seq)
  - camera intrinsics/extrinsics `.npz`
  - point cloud `.ply`
  - génération d’un script Blender pour exporter caméra + pointcloud en **FBX** ou **Alembic**

DA3 fournit depth, intrinsics, extrinsics et plusieurs formats d’export dans sa codebase citeturn1view0

### Export FBX / Alembic via Blender
L’app génère `exports/depth_anything3/blender_export/export_da3_to_fbx_or_abc.py`.

Exemple :
```bash
blender -b -P exports/depth_anything3/blender_export/export_da3_to_fbx_or_abc.py -- --out_format abc
```

---

## 5) Notes perf (RTX 4090)
- Utiliser `bfloat16` quand dispo (auto dans l’app)
- Pour DA3 : stride pointcloud = 4 (réglable dans le code) pour éviter les fichiers énormes

---

## 6) Structure projet
- `sam3roto/backend/sam3_backend.py` : wrappers SAM3 (PCS/PVS image/vidéo)
- `sam3roto/post/*` : matte refine, despill, edge extend, composite
- `sam3roto/depth/*` : DA3 wrapper + geometry + export blender
- `sam3roto/app.py` : GUI PySide6

